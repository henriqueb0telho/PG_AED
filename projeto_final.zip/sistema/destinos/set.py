def set_name(self, name):
    self._name = name

def set_country(self, country):
    self._country = country

def set_city(self, city):
    self._city = city

def set_near_airport(self, near_airport):
    self._near_airport = near_airport

def set_coordinates(self, coordinates):
    self._coordinates = coordinates

def set_url(self, url):
    self._url = url

def set_searches(self, searches):
    self._searches = searches

def set_next(self, next):
    self._next = next