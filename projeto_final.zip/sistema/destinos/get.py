def get_name(self):
        return self._name

def get_country(self):
    return self._country

def get_city(self):
    return self._city

def get_near_airport(self):
    return self._near_airport

def get_coordinates(self):
    return self._coordinates

def get_url(self):
    return self._url

def get_searches(self):
    return self._searches

def get_next(self):
    return self._next