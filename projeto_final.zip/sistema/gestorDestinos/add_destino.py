def add_destino(self, destino):
        self._destinos.append(destino)