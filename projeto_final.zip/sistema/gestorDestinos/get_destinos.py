def get_destinos(self):
        return self._destinos