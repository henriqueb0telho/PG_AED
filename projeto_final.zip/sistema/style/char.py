class char:
    dot = '\u2022'
    circle = '\u25cf'